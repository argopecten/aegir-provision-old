<?php print '<?php '; ?>
# global settings.php
