This provision extension is designed to enforce privacy of backups in the backup_migrate module.

http://drupal.org/node/642948
