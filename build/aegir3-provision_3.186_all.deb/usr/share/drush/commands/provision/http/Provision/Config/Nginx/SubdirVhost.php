<?php

/**
 * Class for Nginx subdir support.
 */
class Provision_Config_Nginx_SubdirVhost extends Provision_Config_SubdirVhost {
}
