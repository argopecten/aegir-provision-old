<?php

/**
 * Class for Apache subdir support.
 */
class Provision_Config_Apache_SubdirVhost extends Provision_Config_SubdirVhost {
}
